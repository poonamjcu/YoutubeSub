# YouTube Subscription Plugin
This plugin is used to connect the user’s site to the youtube channel. It will also show and counts of subscribers if selected as show. 

# Title
This will display the text on the website. Appears on top of the widget div.

# Channel
This is where user put the channel id; Retrieved from https://www.youtube.com/account_advanced

### Version
0.0.1

### Author
Poonam

### Plugin Site
theme.valancers.com
